(() => {
  const modal = document.querySelector('#acquisitionModal');
  const form = document.querySelector('#requestForm');
  const selectedProduct = document.querySelector('#selectedProduct');
  const closeButton = document.querySelector('.modal-close');
  const menuButton = document.querySelector('.menu-button');
  const siteNav = document.querySelector('.site-nav');
  const deliverySelect = form.querySelector('[name="delivery_estate"]');
  const mapDestinationPanel = document.querySelector('#mapDestinationPanel');
  const mapDestinationLabel = document.querySelector('#mapDestinationLabel');
  const mapDestinationLink = document.querySelector('#mapDestinationLink');
  const requestConfirmation = document.querySelector('#requestConfirmation');
  const requestReference = document.querySelector('#requestReference');
  const requestError = document.querySelector('#requestError');
  const confirmationClose = document.querySelector('#confirmationClose');
  const submitButton = form.querySelector('.submit-button');
  const acquireButtons = document.querySelectorAll('.acquire-button');
  let lastTrigger = null;
  let selectedProductId = '';

  const deliveryDestinations = {
    Sandton: 'Sandton, Johannesburg, South Africa',
    Bryanston: 'Bryanston, Sandton, Johannesburg, South Africa',
    'Pretoria East': 'Pretoria East, Pretoria, South Africa',
    Centurion: 'Centurion, Gauteng, South Africa',
    'Steyn City': 'Steyn City, Johannesburg, South Africa',
    Waterfall: 'Waterfall City, Midrand, South Africa',
    'Woodhill Estate': 'Woodhill Estate, Pretoria, South Africa',
    Other: 'South Africa'
  };

  const setRequestItem = (button) => {
    selectedProductId = button.dataset.productId || '';
    selectedProduct.textContent = button.dataset.product || '';
  };

  const resetRequestState = () => {
    form.reset();
    form.hidden = false;
    requestConfirmation.hidden = true;
    requestError.hidden = true;
    requestError.textContent = '';
    submitButton.disabled = false;
    submitButton.innerHTML = 'Send Private Acquisition Request <span aria-hidden="true">↗</span>';
    mapDestinationPanel.hidden = true;
    requestReference.textContent = '';
  };

  const openModal = (button) => {
    lastTrigger = button;
    resetRequestState();
    setRequestItem(button);
    if (typeof modal.showModal === 'function') {
      modal.showModal();
    } else {
      modal.setAttribute('open', '');
    }
    document.body.classList.add('modal-open');
    window.setTimeout(() => {
      const nameField = form.querySelector('[name="name_first"]');
      nameField?.focus();
    }, 120);
  };

  const closeModal = () => {
    if (typeof modal.close === 'function' && modal.open) {
      modal.close();
    } else {
      modal.removeAttribute('open');
    }
    document.body.classList.remove('modal-open');
    lastTrigger?.focus();
  };

  const updateMapDestination = () => {
    const value = deliverySelect.value;
    const destination = deliveryDestinations[value];
    if (!destination) {
      mapDestinationPanel.hidden = true;
      return;
    }
    const label = deliverySelect.options[deliverySelect.selectedIndex].textContent;
    mapDestinationLabel.textContent = label;
    mapDestinationLink.href = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(destination)}`;
    mapDestinationPanel.hidden = false;
  };

  const showRequestError = (message) => {
    requestError.textContent = message;
    requestError.hidden = false;
  };

  const submitRequest = async (event) => {
    event.preventDefault();
    requestError.hidden = true;
    submitButton.disabled = true;
    submitButton.textContent = 'Sending request…';

    const formData = new FormData(form);
    const payload = {
      productId: selectedProductId,
      name: formData.get('name_first'),
      email: formData.get('email_address'),
      phone: formData.get('cell_number'),
      deliveryEstate: formData.get('delivery_estate'),
      deliveryEstateLabel: deliverySelect.options[deliverySelect.selectedIndex]?.textContent.trim() || ''
    };

    try {
      const response = await fetch('/api/purchase-request', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify(payload)
      });
      const result = await response.json().catch(() => ({}));
      if (!response.ok || !result.ok) {
        throw new Error(result.message || 'We could not send your request.');
      }
      form.hidden = true;
      requestReference.textContent = `Request reference / ${result.reference}`;
      requestConfirmation.hidden = false;
      requestConfirmation.querySelector('a')?.focus();
    } catch (error) {
      submitButton.disabled = false;
      submitButton.innerHTML = 'Send Private Acquisition Request <span aria-hidden="true">↗</span>';
      showRequestError(`${error.message} You can also contact lee@thulare.com directly.`);
    }
  };

  acquireButtons.forEach((button) => {
    button.addEventListener('click', () => openModal(button));
  });

  closeButton.addEventListener('click', closeModal);
  confirmationClose.addEventListener('click', closeModal);
  deliverySelect.addEventListener('change', updateMapDestination);
  form.addEventListener('submit', submitRequest);
  modal.addEventListener('click', (event) => {
    if (event.target === modal) closeModal();
  });
  modal.addEventListener('cancel', (event) => {
    event.preventDefault();
    closeModal();
  });

  menuButton.addEventListener('click', () => {
    const isOpen = siteNav.classList.toggle('is-open');
    menuButton.classList.toggle('is-open', isOpen);
    menuButton.setAttribute('aria-expanded', String(isOpen));
  });

  siteNav.querySelectorAll('a').forEach((link) => {
    link.addEventListener('click', () => {
      siteNav.classList.remove('is-open');
      menuButton.classList.remove('is-open');
      menuButton.setAttribute('aria-expanded', 'false');
    });
  });
})();
