# Thulare Website Outcomes

## Luxury editorial foundation and responsive shell
- Use a high-contrast minimalist luxury palette with pure deep black backgrounds (#000000), crisp white text (#FFFFFF), and subtle muted grey borders (#222222).
- Use elegant high-fashion serif headers such as Playfair Display or Cormorant Garamond with wide letter-spacing (0.15em), paired with clean ultra-readable sans-serif body text such as Inter or Helvetica Neue at light weights.
- Use generous layout padding, massive margins, breathing room, zero clutter, beautiful grid lines, and fully responsive behavior for desktop, iPad Pro, and iPhone Pro/Max dimensions.
- Deliver semantic HTML5, CSS variables, accessible controls, and clean vanilla JavaScript in readable source suitable for direct public_html deployment and later minification.

## Editorial hero and showroom collection
- Include a full-screen editorial hero with the headline "Thulare. Private Acquisition & Curated Living.".
- Include the exact service subheadline: "Bespoke furniture concierge and white-glove transport serving the South African executive tier. Inspected, sourced, and discreetly delivered directly to your residence in Sandton, Pretoria, and Centurion."
- Include a thin white-bordered no-fill primary action button labeled "Explore the Collection" that smooth-scrolls to the showroom.
- Include an immaculate responsive four-piece CSS Grid showroom with oversized high-ratio visual boxes and minimalist details.
- Present the supplied product titles, subtitles, rand prices, and premium "Acquire Piece" action for all four showroom pieces, with product one shown as "Connery 5 Motion Fabric Lounge Suite With Lights & USB Charge", priced at "R50,000", and using the supplied Connery lounge suite image; product two shown as "Hisense 536L Water And Ice French Door Fridge", priced at "R50,000" and using the supplied Hisense refrigerator image; product three shown as "Lunar Centara 183cm Extra Length Lux Pillow Top Base Set", priced at "R37,500" and using the supplied Lunar Centara mattress image; product four shown as "La Germania 90cm Stove 5 Gas Hobs. Elec Oven Ams95c61lbx", priced at "R43,000" and using the supplied La Germania stove image.

## Acquisition modal and customer details
- Clicking any "Acquire Piece" action opens a smooth animated acquisition modal with a dark #050505 surface, blurred backdrop using backdrop-filter: blur(10px), accessible open/close behavior, and selected-piece context.
- The modal form uses crisp white minimalist bottom borders and contains Full Name with placeholder "e.g., Jonathan Khumalo", Corporate Email with placeholder "e.g., j.khumalo@firm.co.za", Contact Number with placeholder "e.g., +27 82 000 0000", and Delivery Estate / Suburb.
- The Delivery Estate / Suburb dropdown includes exactly Sandton, Bryanston, Pretoria East, Centurion, Woodhill Estate, Waterfall Estate, and Other.

## Private invoice-request workflow replacing PayFast for now
- Remove the active PayFast action, merchant placeholders, hidden payment fields, PayFast checkout language, and direct payment submission from the acquisition modal.
- Keep the selected product, customer full name, corporate email, contact number, delivery estate, and Google Maps destination preview in the private request form.
- On request submission, validate the selected product and server-owned price, send the request to `POST /api/purchase-request`, and show the customer: "Request received. We will send your invoice shortly."
- Include a unique request reference in the confirmation and tell the customer that a Thulare concierge will send the invoice shortly.
- Send the project owner a private operational notification containing the request reference, customer details, selected product, amount, delivery estate, destination map URL, and submission time so the owner can prepare and send the invoice manually to the customer.
- Keep the support contacts `lee@thulare.com` and `+27 71 846 0475` visible in the modal and footer.

## Footer and deployment readiness
- Include the exact footer microcopy: "Thulare Concierge Group © 2026. Private Operations. Sandton, South Africa. All Rights Reserved."
- Serve the complete route set through /manus-routes.json with the root page declared.
- Configure the project as a no-build static deployment whose output contains index.html and can be uploaded directly to public_html.

## Discreet acquisitions and corporate proof
- Add a "Discreet Acquisitions" section with the subtitle "Recent white-glove installations across private estates in Sandton, Pretoria, and Centurion."
- Add two delivered-goods gallery cards with the exact verified-installation labels for Bryanston Penthouse Residence and Silver Lakes Architectural Home, plus their exact white-glove delivery microcopy; use the supplied Bryanston installation photo in the first card and supplied refrigerator installation photo in the second card.
- Add both exact corporate executive testimonials and their attribution lines in an editorial testimonial grid.
- Update the acquisition modal copy to "Request Private Acquisition", "Selected Luxury Asset", "Full Corporate Name", "Secure Communication Email", "Direct Contact Number", and "Delivery Estate Matrix" with the "Select Secure Destination" prompt and the feedback's named estate options, while preserving the original Woodhill Estate and Other options.

## Trust, comfort, and considered customer journey
- Add a human reassurance line that positions Thulare as a real conversation from selection to placement.
- Add a warm client-care section explaining what happens before commitment, during transit, at delivery, and when the customer needs a person.
- Add clear checkout reassurance that the selected asset, Rand amount, and delivery area can be reviewed before the PayFast handoff.
- Keep the visual language natural and comfortable through a warm paper-toned client-care section, restrained accordions, and a non-pressuring note that prioritizes choosing the right piece over rushing a sale.

## Delivery maps and customer support
- Integrate the Delivery Estate Matrix with Google Maps: selecting an estate updates an "Open in Google Maps" link using the destination's named South African locality, without requiring a customer-facing API key.
- Add customer support contact details as clickable links: lee@thulare.com and +27 71 846 0475, visible in the footer and acquisition modal.

## Invoice-request operations
- The live request endpoint must remain server-backed and must never expose the Manus API key or future email-provider credentials to the browser.
- The current implementation sends a project-owner operational notification; guaranteed direct delivery to lee@thulare.com requires the project owner notification destination to be that address or a connected transactional email provider.

## Direct customer-request email plan
- Use a dedicated transactional email provider, with Resend as the recommended first option, rather than exposing SMTP credentials or relying on a browser `mailto:` link.
- Verify `thulare.com` with the provider and use a domain sender such as `concierge@thulare.com` or `lee@thulare.com`.
- Store the provider API key only as a protected server secret and send a server-generated email to `lee@thulare.com` containing the request reference, customer details, selected product, R50,000 Connery amount where applicable, delivery estate, Google Maps URL, and submission time.
- Keep the existing owner notification as a fallback and return the customer confirmation only after the request has been accepted by the server.
- Test with a real request in provider test mode, verify delivery to `lee@thulare.com`, confirm the sender domain passes authentication, and then switch the provider key and sender to live mode.
