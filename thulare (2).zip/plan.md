# Thulare Private Invoice-Request Workflow

## Product outcome
Replace the paused PayFast checkout with a private acquisition request flow. A customer selects a piece, enters their contact and delivery details, submits a request, and sees a calm confirmation stating that Thulare will send an invoice shortly. The project owner receives the request details through the server-side owner-notification channel so the invoice can be prepared and sent manually.

## Implementation approach
- Replace the PayFast POST form with a JSON request form that submits to `POST /api/purchase-request`.
- Add a small Node.js application server that serves the existing `public/` assets in Preview/container runtime, responds to `GET /_health`, validates and normalizes the request, creates a unique request reference, and sends a compact owner notification through the supplied Manus runtime API.
- Keep all product prices server-validated from an allowlist; never trust a browser-supplied price or product name.
- Return a friendly success payload containing the request reference and the exact customer-facing message: "Request received. We will send your invoice shortly.".
- Degrade gracefully when the owner notification service is unavailable: the customer still receives a request reference and the server logs a clear operational error; the response includes notification status for future operational handling without exposing credentials.
- Retain the Google Maps destination preview and support contact details.

## Design decisions
- **Design movement:** quiet luxury editorial commerce with a warm, human concierge layer.
- **Core principles:** clarity before conversion; real human contact; discreet handling; no pressure.
- **Color philosophy:** preserve the deep-black gallery and use warm paper tones only for care and confirmation surfaces, making the request feel considered rather than transactional.
- **Layout paradigm:** the existing editorial sequence leads into a focused private-request surface; the confirmation state is a calm, full-width editorial panel rather than a generic toast.
- **Signature elements:** thin rules, generous whitespace, numbered field labels, and the Thulare T mark as a quiet assurance.
- **Interaction philosophy:** a customer should always know which piece they selected, what happens next, and how to reach a person.
- **Animation:** retain the modal blur/fade; use a short, reduced-motion-safe transition from form to confirmation.
- **Typography system:** existing serif display headlines with restrained sans-serif labels and form copy.
- **Brand essence:** a private acquisition channel for South African executive homes, differentiated by considered sourcing and discreet delivery. Personality: restrained, personal, assured.
- **Brand voice:** clear, discreet, human. Example lines: "Tell us what you are considering." and "Your request is with the concierge; an invoice will follow shortly."
- **Wordmark & logo:** retain the existing circular T mark and editorial THULARE wordmark.
- **Signature brand color:** warm paper `#d8d0c2` used only for care and confirmation surfaces.

## Project structure
- `public/index.html`: showroom, acquisition modal, request form, and confirmation markup.
- `public/styles.css`: existing luxury system plus request-state styling.
- `public/script.js`: modal state, selected product state, request submission, maps link, and confirmation behavior.
- `server.mjs`: static file server, health endpoint, request validation, and owner notification call.
- `Dockerfile`: reproducible Node runtime for managed server deployment.
- `public/manus-routes.json`: root page declaration; API and health endpoints remain excluded as required.

## Direct email delivery plan
The current server sends an operational alert through the project-owner notification channel, but that channel does not guarantee delivery to an arbitrary mailbox. To guarantee delivery to `lee@thulare.com`, connect a transactional email provider; Resend is the recommended first implementation because it can send a server-side transactional message through a verified domain without exposing credentials to the browser.

The next implementation step is to verify `thulare.com` with the provider, choose a sender such as `concierge@thulare.com`, store the provider API key through protected server configuration, and add a server-side email call after request validation. The email will include the request reference, customer name, corporate email, phone, selected piece, server-owned amount, delivery estate, Google Maps destination, and submission timestamp. The existing owner notification remains a fallback. A sandbox request and a live mailbox delivery check must pass before the feature is treated as operational.

## Material constraints
- Do not retain PayFast credentials, PayFast form action, or PayFast checkout language in the active request flow.
- Do not expose `MANUS_API_KEY` or any future email-provider key to the browser.
- The owner-notification channel is a project-owner operational alert; it is not a customer-email service. Direct delivery to `lee@thulare.com` remains dependent on that address being the project owner notification destination or on adding a dedicated email provider later.
