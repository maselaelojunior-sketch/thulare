import { createServer } from 'node:http';
import { createReadStream, existsSync, statSync } from 'node:fs';
import { extname, join, normalize, relative, resolve } from 'node:path';
import { randomBytes } from 'node:crypto';
import { fileURLToPath } from 'node:url';

const rootDir = resolve(fileURLToPath(new URL('.', import.meta.url)));
const publicDir = resolve(rootDir, 'public');
const port = Number(process.env.PORT || 3000);
const maxBodyBytes = 32 * 1024;

const products = {
  'connery-lounge': {
    name: 'Connery 5 Motion Fabric Lounge Suite With Lights & USB Charge',
    amount: '50000.00'
  },
  'hisense-fridge': {
    name: 'Hisense 536L Water And Ice French Door Fridge',
    amount: '50000.00'
  },
  'lunar-centara': {
    name: 'Lunar Centara 183cm Extra Length Lux Pillow Top Base Set',
    amount: '37500.00'
  },
  'la-germania-stove': {
    name: 'La Germania 90cm Stove 5 Gas Hobs. Elec Oven Ams95c61lbx',
    amount: '43000.00'
  }
};

const deliveryDestinations = {
  Sandton: 'Sandton, Johannesburg, South Africa',
  Bryanston: 'Bryanston, Sandton, Johannesburg, South Africa',
  'Pretoria East': 'Pretoria East, Pretoria, South Africa',
  Centurion: 'Centurion, Gauteng, South Africa',
  'Steyn City': 'Steyn City, Johannesburg, South Africa',
  Waterfall: 'Waterfall City, Midrand, South Africa',
  'Woodhill Estate': 'Woodhill Estate, Pretoria, South Africa',
  Other: 'South Africa'
};

const contentTypes = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.png': 'image/png',
  '.webp': 'image/webp'
};

const cleanText = (value, maxLength) => String(value ?? '').replace(/[\u0000-\u001f\u007f]/g, ' ').trim().slice(0, maxLength);
const isEmail = (value) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);

const sendJson = (res, status, payload) => {
  const body = JSON.stringify(payload);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff'
  });
  res.end(body);
};

const readJson = async (req) => {
  const chunks = [];
  let size = 0;
  for await (const chunk of req) {
    size += chunk.length;
    if (size > maxBodyBytes) throw new Error('request_too_large');
    chunks.push(chunk);
  }
  const raw = Buffer.concat(chunks).toString('utf8');
  return JSON.parse(raw || '{}');
};

const makeReference = () => {
  const stamp = new Date().toISOString().slice(0, 10).replaceAll('-', '');
  return `TH-${stamp}-${randomBytes(3).toString('hex').toUpperCase()}`;
};

const buildRequestContent = ({ reference, customer, product, estate, destination, submittedAt }) => [
  `New private acquisition request: ${reference}`,
  '',
  `Customer: ${customer.name}`,
  `Email: ${customer.email}`,
  `Contact: ${customer.phone}`,
  `Selected asset: ${product.name}`,
  `Amount to invoice: R${Number(product.amount).toLocaleString('en-ZA', { minimumFractionDigits: 2 })}`,
  `Delivery estate: ${estate.label}`,
  `Mapped destination: ${destination}`,
  `Google Maps: https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(destination)}`,
  `Submitted: ${submittedAt}`,
  '',
  'Next action: contact the customer and send the invoice from lee@thulare.com.'
].join('\n');

const sendResendEmail = async (request) => {
  const resendKey = process.env.RESEND_API_KEY;
  if (!resendKey) throw new Error('resend_api_key_unavailable');

  const response = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${resendKey}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      from: process.env.RESEND_FROM_EMAIL || 'Thulare Concierge <lee@thulare.com>',
      to: ['lee@thulare.com'],
      subject: `Thulare private invoice request ${request.reference}`,
      text: buildRequestContent(request)
    })
  });
  if (!response.ok) {
    const detail = (await response.text()).slice(0, 500);
    throw new Error(`resend_email_failed_${response.status}:${detail}`);
  }
};

const sendOwnerNotification = async (request) => {
  const apiUrl = String(process.env.MANUS_API_URL || '').replace(/\/$/, '');
  const apiKey = process.env.MANUS_API_KEY;
  if (!apiUrl || !apiKey) throw new Error('owner_notification_environment_unavailable');

  const response = await fetch(`${apiUrl}/webdevtoken.v1.WebDevService/SendNotification`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${apiKey}`,
      'Content-Type': 'application/json',
      'connect-protocol-version': '1'
    },
    body: JSON.stringify({
      title: `Thulare private invoice request ${request.reference}`,
      content: buildRequestContent(request)
    })
  });
  if (!response.ok) {
    const detail = (await response.text()).slice(0, 500);
    throw new Error(`owner_notification_failed_${response.status}:${detail}`);
  }
};

const handlePurchaseRequest = async (req, res) => {
  try {
    const body = await readJson(req);
    const product = products[cleanText(body.productId, 80)];
    const name = cleanText(body.name, 100);
    const email = cleanText(body.email, 160);
    const phone = cleanText(body.phone, 40);
    const estateValue = cleanText(body.deliveryEstate, 80);
    const destination = deliveryDestinations[estateValue];
    const estateLabel = cleanText(body.deliveryEstateLabel, 120) || estateValue;

    if (!product || !name || name.length < 2 || !isEmail(email) || !phone || phone.length < 7 || !destination) {
      return sendJson(res, 400, { ok: false, message: 'Please check your details and selected delivery destination.' });
    }

    const reference = makeReference();
    const request = {
      reference,
      customer: { name, email, phone },
      product,
      estate: { value: estateValue, label: estateLabel },
      destination,
      submittedAt: new Date().toISOString()
    };
    let emailSent = false;
    let ownerNotificationSent = false;
    try {
      await sendResendEmail(request);
      emailSent = true;
    } catch (error) {
      console.error(`[${reference}] Resend email failed`, error);
    }
    if (!emailSent) {
      try {
        await sendOwnerNotification(request);
        ownerNotificationSent = true;
      } catch (error) {
        console.error(`[${reference}] owner notification fallback failed`, error);
      }
    }

    return sendJson(res, 200, {
      ok: true,
      reference,
      emailSent,
      ownerNotificationSent,
      notificationSent: emailSent || ownerNotificationSent,
      message: 'Request received. We will send your invoice shortly.'
    });
  } catch (error) {
    if (error.message === 'request_too_large') {
      return sendJson(res, 413, { ok: false, message: 'That request is too large. Please try again.' });
    }
    console.error('purchase request failed', error);
    return sendJson(res, 400, { ok: false, message: 'We could not read that request. Please try again.' });
  }
};

const serveStatic = async (req, res, pathname) => {
  const requested = pathname === '/' ? '/index.html' : pathname;
  const filePath = normalize(join(publicDir, requested));
  const relativePath = relative(publicDir, filePath);
  if (relativePath.startsWith('..') || relativePath.includes('..' + requireSeparator())) {
    return sendJson(res, 404, { ok: false, message: 'Not found' });
  }
  if (!existsSync(filePath) || !statSync(filePath).isFile()) {
    return sendJson(res, 404, { ok: false, message: 'Not found' });
  }
  const type = contentTypes[extname(filePath).toLowerCase()] || 'application/octet-stream';
  res.writeHead(200, {
    'Content-Type': type,
    'Cache-Control': extname(filePath) === '.html' ? 'no-store' : 'public, max-age=3600',
    'X-Content-Type-Options': 'nosniff'
  });
  if (req.method === 'HEAD') return res.end();
  createReadStream(filePath).pipe(res);
};

const requireSeparator = () => process.platform === 'win32' ? '\\' : '/';

const server = createServer(async (req, res) => {
  const url = new URL(req.url || '/', `http://${req.headers.host || 'localhost'}`);
  if (req.method === 'GET' && url.pathname === '/_health') {
    return sendJson(res, 200, { ok: true, service: 'thulare' });
  }
  if (req.method === 'POST' && url.pathname === '/api/purchase-request') {
    return handlePurchaseRequest(req, res);
  }
  if (req.method === 'GET' || req.method === 'HEAD') {
    return serveStatic(req, res, decodeURIComponent(url.pathname));
  }
  return sendJson(res, 405, { ok: false, message: 'Method not allowed' });
});

server.listen(port, '0.0.0.0', () => {
  console.log(`Thulare server listening on 0.0.0.0:${port}`);
});
